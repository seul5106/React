import { combineReducers } from 'redux';
import kakaoImageSearchReducer from './KakaoImageSearchReducer';

export default combineReducers({
    kakaoImageSearchReducer
});