const Footer = () => {
    return (
        <div>
            <hr />
            <div className="container">
                <div className="row">
                    <div className="col-md-6">copyright&copy;2020</div>
                    <div className="col-md-6 text-right">Hello Nextjs</div>
                </div>
            </div>
        </div>
    );
}

export default Footer;