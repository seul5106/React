# 14-movie-rank

## #01. 프로젝트 생성

```shell
yarn create next-app 15-nextjs
```

### 1) 추가 패키지 설치

프로젝트를 VSCode로 열고, `Ctrl` + `~`를 눌러 터미널 실행

```shell
yarn add styled-components
yarn add babel-plugin-styled-components
```
