const MyError = () => {
    return (
        <div className='container'>
            <h1>Opps!!!</h1>
            <h2>404에러가 발생했습니다.</h2>
        </div>
    );

};

export default MyError;