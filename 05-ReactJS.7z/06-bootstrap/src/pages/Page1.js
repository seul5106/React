import React from 'react';

const Page1 = () => {
    return (
        <div className="container">
            <div className="page-header">
                <h2>Page1</h2>
            </div>
        </div>
    );
};

export default Page1;