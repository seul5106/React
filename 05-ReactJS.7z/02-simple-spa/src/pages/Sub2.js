import React from 'react';

const Sub2 = () => {
    return (
        <div>
            <h3>여기는 sub2 입니다.</h3>
        </div>
    );
};

export default Sub2;